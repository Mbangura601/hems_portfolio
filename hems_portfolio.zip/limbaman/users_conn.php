<?php
$conn = new mysqli('sqlXXX.infinityfree.com', 'epiz_XXXXX', 'YOUR_DB_PASSWORD', 'epiz_XXXXX_limbaman');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$full_name = $_POST['full_name'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

if (!$full_name || !$email || !$password || !$confirm_password) {
    header("Location: signup.php?status=missing");
    exit();
}

if ($password !== $confirm_password) {
    header("Location: signup.php?status=mismatch");
    exit();
}

// Check if email exists
$check = $conn->prepare("SELECT id FROM visitors WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    header("Location: signup.php?status=exists");
    exit();
}

$check->close();

// Hash password
$hashed = password_hash($password, PASSWORD_BCRYPT);

// Insert new visitor
$stmt = $conn->prepare("INSERT INTO visitors(full_name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $full_name, $email, $hashed);

if ($stmt->execute()) {
    header("Location: signup.php?status=success");
} else {
    header("Location: signup.php?status=error");
}

$stmt->close();
$conn->close();
exit();
?>
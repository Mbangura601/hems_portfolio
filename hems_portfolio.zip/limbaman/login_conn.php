<?php
session_start();

$conn = new mysqli('sqlXXX.infinityfree.com', 'epiz_XXXXX', 'YOUR_DB_PASSWORD', 'epiz_XXXXX_limbaman');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, email, password FROM visitors WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {

        // Verify hashed password
        if (password_verify($password, $row['password'])) {
            
            $_SESSION['email'] = $row['email'];
            header("Location: index.php");
            exit();

        } else {
            header("Location: login.php?error=wrongpass");
            exit();
        }

    } else {
        header("Location: login.php?error=notfound");
        exit();
    }
}
?>
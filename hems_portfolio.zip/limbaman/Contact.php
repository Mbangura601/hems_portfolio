<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"> <!-- ← this line -->
    <link rel="stylesheet" href="css/contact.css">
</head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">

            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="images/mb.png" alt="Logo" width="80" height="60" class="me-2">
                Momoh Hemon-Bangura
            </a>

            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="skills.php">Skills</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Project.php">Project</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonial.php">Testimonials</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link logout-btn" href="logout.php">Logout</a> <!-- ← fixed double class -->
                        </li>
                    </ul>
                </div>
            </div>

            <button id="themeToggle" class="btn ms-3">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>

        </div>
    </nav>
    <!-- ================= CONTACT WRAPPER ================= -->
<div class="contact_wrapper fade-in">

    <!-- LEFT SIDE -->
    <div class="info_section">

        <h2>Get in Touch</h2>
        <p class="subtitle">Let's build something amazing together.</p>
        <p>I'm available for freelance work, collaborations, and full-time opportunities in Front-End and Mobile App Development.</p>

        <div class="contact_box">
            <p><strong>Email</strong> mbangura601@gmail.com</p>
            <p><strong>Phone</strong> +232 88 392 627</p>
            <p><strong>Location</strong> Freetown, Sierra Leone</p>
        </div>

        <div class="availability">
            <span class="dot"></span> Available for work
        </div>

        <div class="socials">
            <p>Follow me</p>
            <a href="https://www.facebook.com/share/1DbsV5ZSDf/" target="_blank">Facebook</a>
            <a href="https://github.com/Mbangura601" target="_blank">GitHub</a>
            <a href="https://www.instagram.com/limba_man1?igsh=Z21ncGVmaTUxNGR1" target="_blank">Instagram</a>
        </div>

        <div class="quick_contact">
            <a href="https://wa.me/23288392726?text=Hello%20I%20am%20interested%20in%20your%20services"
               target="_blank" class="whatsapp_btn">&#128242; Chat on WhatsApp</a>
            <a href="mailto:mbangura601@gmail.com?subject=Project%20Inquiry&body=Hello%20I%20would%20like%20to%20discuss%20a%20project"
               class="email_btn">&#128231; Send Email</a>
        </div>

    </div>

    <!-- RIGHT SIDE FORM -->
    <div class="form_box">
        <form id="contactForm" action="connect.php" method="post">

            <label>Full name</label>
            <input type="text" name="full_name" placeholder="Your full name" required>

            <label>Email</label>
            <input type="email" name="email" placeholder="your@email.com" required>

            <label>Message</label>
            <textarea name="message" placeholder="Hello, I'd like to discuss a project..." required></textarea>

            <button type="submit">Send message</button>

        </form>
    </div>

</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <script src="js/contact.js"></script>
  </body>
</html>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"> <!-- ← this line -->
    <link rel="stylesheet" href="css/project.css">
</head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">

            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="images/mb.png" alt="Logo" width="80" height="60" class="me-2">
                Momoh Hemon-Bangura
            </a>

            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active"  href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="skills.php">Skills</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonial.php">Testimonials</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Contact.php">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link logout-btn" href="logout.php">Logout</a> <!-- ← fixed double class -->
                        </li>
                    </ul>
                </div>
            </div>

            <button id="themeToggle" class="btn ms-3">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>

        </div>
    </nav>
    <!-- ================= PROJECT HEADER ================= -->
<section class="project-header">
    <h1>My Projects</h1>
    <p>Explore my work in web development, mobile apps, and UI design.</p>
    <input type="text" id="searchInput" placeholder="Search projects...">
</section>

<!-- ================= FILTER BUTTONS ================= -->
<div class="filters">
    <button class="filter-btn active" data-filter="all">All</button>
    <button class="filter-btn" data-filter="web">Web</button>
    <button class="filter-btn" data-filter="mobile">Mobile</button>
    <button class="filter-btn" data-filter="ui">UI Design</button>
</div>

<!-- ================= PROJECT GRID ================= -->
<section class="project-grid">

    <div class="project-card web">
        <span class="tag">Web</span>
        <h3>Portfolio Website</h3>
        <p>Responsive personal portfolio built with HTML, CSS, JS, PHP.</p>
        <div class="card-links">
            <a href="#">Live Demo</a>
            <a href="#">GitHub</a>
        </div>
    </div>

    <div class="project-card mobile">
        <span class="tag">Mobile</span>
        <h3>Food Delivery App</h3>
        <p>Mobile UI concept for food ordering system.</p>
        <div class="card-links">
            <a href="#">Live Demo</a>
            <a href="#">GitHub</a>
        </div>
    </div>

    <div class="project-card ui">
        <span class="tag">UI Design</span>
        <h3>Dashboard UI</h3>
        <p>Modern admin dashboard interface design.</p>
        <div class="card-links">
            <a href="#">Live Demo</a>
            <a href="#">GitHub</a>
        </div>
    </div>

    <div class="project-card web">
        <span class="tag">Web</span>
        <h3>E-commerce Website</h3>
        <p>Online shop with product listing and cart system.</p>
        <div class="card-links">
            <a href="#">Live Demo</a>
            <a href="#">GitHub</a>
        </div>
    </div>

</section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <script src="js/project.js"></script>
  </body>
</html>

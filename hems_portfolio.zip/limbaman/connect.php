<?php

// 🔌 DATABASE CONNECTION (UPDATE FOR INFINITYFREE)
$conn = new mysqli('sqlXXX.infinityfree.com', 'epiz_XXXXX', 'YOUR_DB_PASSWORD', 'epiz_XXXXX_limbaman');

// Check connection FIRST
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// 🧹 CLEAN INPUT
$full_name = trim($_POST['full_name']);
$email     = trim($_POST['email']);
$message   = trim($_POST['message']);

// ✅ VALIDATION
if (!$full_name || !$email || !$message) {
    header("Location: Contact_info.php?status=missing");
    exit();
}

// Optional: validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: Contact_info.php?status=invalid_email");
    exit();
}

// 🧱 PREPARE STATEMENT
$stmt = $conn->prepare("INSERT INTO contact (full_name, email, message) VALUES (?, ?, ?)");

// Check if prepare failed
if (!$stmt) {
    header("Location: Contact_info.php?status=error");
    exit();
}

// Bind and execute
$stmt->bind_param("sss", $full_name, $email, $message);

if ($stmt->execute()) {
    header("Location: Contact_info.php?status=success");
} else {
    header("Location: Contact_info.php?status=error");
}

$stmt->close();
$conn->close();
exit();
?>
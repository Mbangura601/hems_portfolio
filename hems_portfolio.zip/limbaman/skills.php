<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Skills</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"> <!-- ← this line -->
    <link rel="stylesheet" href="css/skills.css">
</head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">

            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="images/mb.png" alt="Logo" width="80" height="60" class="me-2">
                Momoh Hemon-Bangura
            </a>

            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Project.php">Project</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonial.php">Testimonials</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Contact.php">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link logout-btn" href="logout.php">Logout</a> <!-- ← fixed double class -->
                        </li>
                    </ul>
                </div>
            </div>

            <button id="themeToggle" class="btn ms-3">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>

        </div>
    </nav>
    <!-- ================= HEADER ================= -->
<header class="skills-header">
    <h1>My Skills</h1>
    <p>Technologies I use to build scalable, modern applications.</p>
</header>

<!-- ================= FILTER BUTTONS ================= -->
<div class="filter-container">
    <button class="filter active" data-filter="all">All</button>
    <button class="filter" data-filter="frontend">Frontend</button>
    <button class="filter" data-filter="backend">Backend</button>
    <button class="filter" data-filter="mobile">Mobile</button>
    <button class="filter" data-filter="tools">Tools</button>
</div>

<!-- ================= SKILLS GRID ================= -->
<section class="skills-grid">

    <div class="skill-card frontend">
        <span class="tag">Frontend</span>
        <h3>HTML</h3>
        <div class="bar"><div class="fill" data-percent="95"></div></div>
        <span class="count">95%</span>
    </div>

    <div class="skill-card frontend">
        <span class="tag">Frontend</span>
        <h3>CSS</h3>
        <div class="bar"><div class="fill" data-percent="90"></div></div>
        <span class="count">90%</span>
    </div>

    <div class="skill-card frontend">
        <span class="tag">Frontend</span>
        <h3>JavaScript</h3>
        <div class="bar"><div class="fill" data-percent="85"></div></div>
        <span class="count">85%</span>
    </div>

    <div class="skill-card backend">
        <span class="tag">Backend</span>
        <h3>PHP</h3>
        <div class="bar"><div class="fill" data-percent="80"></div></div>
        <span class="count">80%</span>
    </div>

    <div class="skill-card backend">
        <span class="tag">Backend</span>
        <h3>MySQL</h3>
        <div class="bar"><div class="fill" data-percent="75"></div></div>
        <span class="count">75%</span>
    </div>

    <div class="skill-card mobile">
        <span class="tag">Mobile</span>
        <h3>Flutter</h3>
        <div class="bar"><div class="fill" data-percent="70"></div></div>
        <span class="count">70%</span>
    </div>

    <div class="skill-card tools">
        <span class="tag">Tools</span>
        <h3>Git / GitHub</h3>
        <div class="bar"><div class="fill" data-percent="85"></div></div>
        <span class="count">85%</span>
    </div>

</section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <script src="js/skills.js"></script>
  </body>
</html>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Testimonial</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"> <!-- ← this line -->
    <link rel="stylesheet" href="css/test.css">
</head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">

            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <img src="images/mb.png" alt="Logo" width="80" height="60" class="me-2">
                Momoh Hemon-Bangura
            </a>

            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="skills.php">Skills</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Project.php">Project</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Contact.php">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link logout-btn" href="logout.php">Logout</a> <!-- ← fixed double class -->
                        </li>
                    </ul>
                </div>
            </div>

            <button id="themeToggle" class="btn ms-3">
                <i id="themeIcon" class="bi bi-moon-fill"></i>
            </button>

        </div>
    </nav>
    <!-- ================= HEADER ================= -->
<header class="page-header">
    <h1>Testimonials</h1>
    <p>What clients and collaborators say about my work</p>
</header>

<!-- ================= TESTIMONIAL GRID ================= -->
<div class="section-label">What people say</div>
<section class="testimonial-container">

    <div class="testimonial-card">
        <div class="tc-top">
            <img src="images/hemon.jpeg" alt="John Doe" class="tc-img">
            <div>
                <h3>John Doe</h3>
                <span>Project Manager</span>
            </div>
        </div>
        <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
        <blockquote>
            Momoh is a talented developer who consistently delivers high-quality work.
            His attention to detail and UX understanding made our project a success.
        </blockquote>
    </div>

    <div class="testimonial-card">
        <div class="tc-top">
            <img src="images/hems.png" alt="Righteous Smith" class="tc-img">
            <div>
                <h3>Righteous Smith</h3>
                <span>Client</span>
            </div>
        </div>
        <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
        <blockquote>
            Working with Momoh was a pleasure. He turned our ideas into a functional app
            that exceeded expectations. Highly recommended!
        </blockquote>
    </div>

    <div class="testimonial-card">
        <div class="tc-top">
            <img src="images/user3.jpg" alt="Ahmed Kamara" class="tc-img">
            <div>
                <h3>Ahmed Kamara</h3>
                <span>Team Lead</span>
            </div>
        </div>
        <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9734;</div>
        <blockquote>
            Professional, creative, and reliable. His code is clean and his UI skills are excellent.
        </blockquote>
    </div>

</section>

<!-- ================= REFERENCES ================= -->
<div class="section-label" style="margin-top: 3rem;">References</div>
<section class="referee-grid">

    <div class="referee-card">
        <div class="ref-avatar">JD</div>
        <div class="ref-info">
            <h4>John Doe</h4>
            <p class="ref-title">Project Manager · Tech Solutions SL</p>
            <p class="ref-contact">johndoe@techsolutions.com</p>
            <p class="ref-note">Available upon request</p>
        </div>
    </div>

    <div class="referee-card">
        <div class="ref-avatar">AK</div>
        <div class="ref-info">
            <h4>Ahmed Kamara</h4>
            <p class="ref-title">Team Lead · Digital Agency SL</p>
            <p class="ref-contact">ahmed.kamara@agency.com</p>
            <p class="ref-note">Available upon request</p>
        </div>
    </div>

    <div class="referee-card">
        <div class="ref-avatar">RS</div>
        <div class="ref-info">
            <h4>Righteous Smith</h4>
            <p class="ref-title">Client · Independent</p>
            <p class="ref-contact">righteous@email.com</p>
            <p class="ref-note">Available upon request</p>
        </div>
    </div>

</section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <script src="js/test.js"></script>
  </body>
</html>

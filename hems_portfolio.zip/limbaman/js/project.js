const body = document.body;
const themeIcon = document.getElementById("themeIcon");

// Load saved theme on page load
const savedTheme = localStorage.getItem("theme");

if (savedTheme === "dark") {
    body.classList.add("dark-mode");
    body.classList.remove("light-mode");
    themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
} else {
    body.classList.add("light-mode");
    body.classList.remove("dark-mode");
    themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
}

// Toggle theme on click (single listener)
document.getElementById("themeToggle").addEventListener("click", () => {
    const isDark = body.classList.contains("dark-mode");

    if (isDark) {
        // Switch to light
        body.classList.replace("dark-mode", "light-mode");
        themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
        localStorage.setItem("theme", "light");
    } else {
        // Switch to dark
        body.classList.replace("light-mode", "dark-mode");
        themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
        localStorage.setItem("theme", "dark");
    }
});

// ===== FILTER BUTTONS =====
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const filter = btn.getAttribute('data-filter');
        document.querySelectorAll('.project-card').forEach(card => {
            if (filter === 'all' || card.classList.contains(filter)) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
    });
});

// ===== SEARCH =====
document.getElementById('searchInput').addEventListener('input', function () {
    const query = this.value.toLowerCase();
    document.querySelectorAll('.project-card').forEach(card => {
        const text = card.innerText.toLowerCase();
        card.style.display = text.includes(query) ? 'flex' : 'none';
    });
});
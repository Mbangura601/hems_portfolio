const body = document.body;
const themeIcon = document.getElementById("themeIcon");

// Load saved theme on page load
const savedTheme = localStorage.getItem("theme");

if (savedTheme === "dark") {
    body.classList.add("dark-mode");
    body.classList.remove("light-mode");
    themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
} else {
    body.classList.add("light-mode");
    body.classList.remove("dark-mode");
    themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
}

// Toggle theme on click (single listener)
document.getElementById("themeToggle").addEventListener("click", () => {
    const isDark = body.classList.contains("dark-mode");

    if (isDark) {
        // Switch to light
        body.classList.replace("dark-mode", "light-mode");
        themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
        localStorage.setItem("theme", "light");
    } else {
        // Switch to dark
        body.classList.replace("light-mode", "dark-mode");
        themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
        localStorage.setItem("theme", "dark");
    }
});


// ===== ANIMATE SKILL BARS =====
window.addEventListener("load", () => {
    document.querySelectorAll(".fill").forEach(bar => {
        bar.style.width = bar.getAttribute("data-percent") + "%";
    });
});

// ===== FILTER BUTTONS =====
document.querySelectorAll(".filter").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const filter = btn.getAttribute("data-filter");
        document.querySelectorAll(".skill-card").forEach(card => {
            if (filter === "all" || card.classList.contains(filter)) {
                card.style.display = "flex";
            } else {
                card.style.display = "none";
            }
        });
    });
});
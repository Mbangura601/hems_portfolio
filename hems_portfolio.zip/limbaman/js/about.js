// ===== THEME TOGGLE =====
const body = document.body;
const themeIcon = document.getElementById("themeIcon");

const savedTheme = localStorage.getItem("theme");

if (savedTheme === "dark") {
    body.classList.add("dark-mode");
    body.classList.remove("light-mode");
    themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
} else {
    body.classList.add("light-mode");
    body.classList.remove("dark-mode");
    themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
}

document.getElementById("themeToggle").addEventListener("click", () => {
    const isDark = body.classList.contains("dark-mode");

    if (isDark) {
        body.classList.replace("dark-mode", "light-mode");
        themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
        localStorage.setItem("theme", "light");
    } else {
        body.classList.replace("light-mode", "dark-mode");
        themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
        localStorage.setItem("theme", "dark");
    }
});

// ===== SKILL BARS =====
window.addEventListener("load", () => {
    document.querySelectorAll(".skill_bar span").forEach(bar => {
        bar.style.width = bar.getAttribute("data-percent");
    });
});
const body = document.body;
const themeIcon = document.getElementById("themeIcon");

// Load saved theme on page load
const savedTheme = localStorage.getItem("theme");

if (savedTheme === "dark") {
    body.classList.add("dark-mode");
    body.classList.remove("light-mode");
    themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
} else {
    body.classList.add("light-mode");
    body.classList.remove("dark-mode");
    themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
}

// Toggle theme on click (single listener)
document.getElementById("themeToggle").addEventListener("click", () => {
    const isDark = body.classList.contains("dark-mode");

    if (isDark) {
        // Switch to light
        body.classList.replace("dark-mode", "light-mode");
        themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
        localStorage.setItem("theme", "light");
    } else {
        // Switch to dark
        body.classList.replace("light-mode", "dark-mode");
        themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
        localStorage.setItem("theme", "dark");
    }
});

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"> <!-- ← was missing -->
    <link rel="stylesheet" href="css/about.css">
</head>
<body>

<!-- NAVBAR — must be first -->
<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">

        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="images/mb.png" alt="Logo" width="80" height="60" class="me-2">
            Momoh Hemon-Bangura
        </a>

        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="skills.php">Skills</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Project.php">Project</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="testimonial.php">Testimonials</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Contact.php">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link logout-btn" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>

        <button id="themeToggle" class="btn ms-3">
            <i id="themeIcon" class="bi bi-moon-fill"></i>
        </button>

    </div>
</nav>

<!-- ABOUT SECTION -->
<section class="about_section fade-in">

    <div class="profile_box">
    <img src="images/hems.png" alt="Profile Image">
    <div>
        <h2>Momoh Hemon-Bangura</h2>
        <p>Front-End | Mobile App Developer · Sierra Leone</p>
        <div class="profile_badges">
            <span>HTML &amp; CSS</span>
            <span>JavaScript</span>
            <span>React</span>
            <span>Flutter</span>
            <span>PHP</span>
        </div>
        <!-- ✅ CV Download Button -->
        <a href="Momoh_Hemon-Bangura_CV.pdf" download class="cv_btn">
            <i class="bi bi-download"></i> Download CV
        </a>

    </div>
</div>
    </div>
</div>

    <div class="about_grid">
        <div class="about_card">
            <i class="bi bi-person-fill about_icon"></i>
            <h5>Who I Am</h5>
            <p>A passionate Front-End and Mobile App Developer dedicated to creating clean, responsive, and user-focused digital experiences.</p>
        </div>
        <div class="about_card">
            <i class="bi bi-code-slash about_icon"></i>
            <h5>What I Use</h5>
            <p>HTML, CSS, JavaScript, React, and Flutter — building visually appealing and highly functional applications.</p>
        </div>
        <div class="about_card">
            <i class="bi bi-bullseye about_icon"></i>
            <h5>My Goal</h5>
            <p>To transform ideas into functional interfaces and mobile apps that solve real problems and deliver value.</p>
        </div>
        <div class="about_card">
            <i class="bi bi-people-fill about_icon"></i>
            <h5>How I Work</h5>
            <p>I thrive in both collaborative and independent environments, always exploring the latest technologies.</p>
        </div>
    </div>

</section>

<section class="skills_section fade-in" id="skills">
    <h3>Skills</h3>

    <div class="skill_row">
        <p>HTML</p>
        <div class="skill_bar"><span data-percent="95%"></span></div>
        <span class="skill_pct">95%</span>
    </div>
    <div class="skill_row">
        <p>CSS</p>
        <div class="skill_bar"><span data-percent="90%"></span></div>
        <span class="skill_pct">90%</span>
    </div>
    <div class="skill_row">
        <p>JavaScript</p>
        <div class="skill_bar"><span data-percent="85%"></span></div>
        <span class="skill_pct">85%</span>
    </div>
    <div class="skill_row">
        <p>React</p>
        <div class="skill_bar"><span data-percent="80%"></span></div>
        <span class="skill_pct">80%</span>
    </div>
    <div class="skill_row">
        <p>Flutter</p>
        <div class="skill_bar"><span data-percent="75%"></span></div>
        <span class="skill_pct">75%</span>
    </div>
    <div class="skill_row">
        <p>Database</p>
        <div class="skill_bar"><span data-percent="85%"></span></div>
        <span class="skill_pct">85%</span>
    </div>
    <div class="skill_row">
        <p>Back-End</p>
        <div class="skill_bar"><span data-percent="50%"></span></div>
        <span class="skill_pct">50%</span>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/about.js"></script>
</body>
</html>
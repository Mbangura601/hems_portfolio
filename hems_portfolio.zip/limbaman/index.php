<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/index.css">
</head>

<body>

<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">

        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="images/mb.png" alt="Logo" width="80" height="60" class="me-2">
            Momoh Hemon-Bangura
        </a>

        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <div class="navbar-nav ms-auto">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="skills.php">Skills</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Project.php">Project</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="testimonial.php">Testimonials</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link logout-btn" href="logout.php">Logout</a> <!-- ← fixed double class -->
                    </li>
                </ul>
            </div>
        </div>

        <button id="themeToggle" class="btn ms-3">
            <i id="themeIcon" class="bi bi-moon-fill"></i>
        </button>

    </div>
</nav>

<div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="images/img2.jpg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
            <img src="images/img1.jpg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
            <img src="images/img3.jpg" class="d-block w-100" alt="...">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<!-- HERO -->
<header class="hero container">
    <div class="hems">
        <h3>Hello, I'm</h3>
        <h1>Momoh Hemon-Bangura</h1>
        <h2 class="typing"></h2> <!-- ← start empty, JS fills it -->
        <p>
            I build modern, responsive, and user-focused websites and mobile applications
            that solve real problems and deliver great user experiences.
        </p>
        <div class="cta">
            <a href="Contact.php" class="btn primary">Hire Me</a>
            <a href="Project.php" class="btn secondary">View Work</a>
        </div>
    </div>
</header>

<!-- ABOUT -->
<section class="section">
    <h2>About Me</h2>
    <div class="about-grid">
        <div class="about-card">
            <i class="bi bi-person-circle about-icon"></i>
            <h5>Who I Am</h5>
            <p>A passionate Front-End and Mobile App Developer focused on creating clean UI and smooth user experiences.</p>
        </div>
        <div class="about-card">
            <i class="bi bi-geo-alt about-icon"></i>
            <h5>Based In</h5>
            <p>Sierra Leone, available for remote work and freelance projects worldwide.</p>
        </div>
        <div class="about-card">
            <i class="bi bi-bullseye about-icon"></i>
            <h5>My Goal</h5>
            <p>To build scalable digital solutions that solve real problems and deliver great experiences.</p>
        </div>
    </div>
</section>

<!-- SKILLS -->
<section class="section">
    <h2>Skills</h2>
    <div class="skills-grid">
        <div class="skill-card">
            <i class="bi bi-filetype-html skill-icon"></i>
            <p>HTML</p>
            <div class="bar"><div class="fill" style="width: 95%"></div></div>
        </div>
        <div class="skill-card">
            <i class="bi bi-filetype-css skill-icon"></i>
            <p>CSS</p>
            <div class="bar"><div class="fill" style="width: 90%"></div></div>
        </div>
        <div class="skill-card">
            <i class="bi bi-filetype-js skill-icon"></i>
            <p>JavaScript</p>
            <div class="bar"><div class="fill" style="width: 50%"></div></div>
        </div>
        <div class="skill-card">
            <i class="bi bi-database skill-icon"></i>
            <p>Database</p>
            <div class="bar"><div class="fill" style="width: 85%"></div></div>
        </div>
        <div class="skill-card">
            <i class="bi bi-server skill-icon"></i>
            <p>Back-End</p>
            <div class="bar"><div class="fill" style="width: 50%"></div></div>
        </div>
    </div>
</section>

<!-- PROJECTS -->
<section class="section">
    <h2>Projects</h2>
    <p>Explore some of my recent work and development projects.</p>
    <div class="cards">
        <div class="card">
            <i class="bi bi-laptop card-icon"></i>
            <h5>Portfolio Website</h5>
            <p>A personal portfolio built with HTML, CSS & JavaScript.</p>
        </div>
        <div class="card">
            <i class="bi bi-phone card-icon"></i>
            <h5>Mobile App UI</h5>
            <p>A modern mobile app interface designed for smooth UX.</p>
        </div>
        <div class="card">
            <i class="bi bi-briefcase card-icon"></i>
            <h5>Business Landing Page</h5>
            <p>A clean landing page built for a local business client.</p>
        </div>
    </div>
    <div class="cta" style="margin-top: 30px;">
        <a href="Project.php" class="btn primary">View Projects</a>
    </div>
</section>

<!-- Scripts — order matters: Bootstrap first, then your JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/index.js"></script> 
</body>
</html>
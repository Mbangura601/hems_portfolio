<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Testimonials</title>

    <link rel="stylesheet" href="css/test.css">
</head>

<body>

<!-- ================= NAVBAR ================= -->
<nav class="navbar">
    <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="about_me.php">About</a></li>
        <li><a href="Project.php">Projects</a></li>
        <li><a href="Skills.php">Skills</a></li>
        <li><a href="Contact_info.php">Contact</a></li>
        <li><a href="logout.php" class="logout-btn">Log Out</a></li>
    </ul>
</nav>

<!-- ================= HEADER ================= -->
<header class="page-header">
    <h1>Testimonials</h1>
    <p>What clients and collaborators say about my work</p>
</header>

<!-- ================= TESTIMONIAL GRID ================= -->
<section class="testimonial-container">

    <div class="testimonial-card">
        <img src="images/hemon.jpeg" alt="John Doe">
        <h3>John Doe</h3>
        <span>Project Manager</span>
        <p>
            “Momoh is a talented developer who consistently delivers high-quality work.
            His attention to detail and UX understanding made our project a success.”
        </p>
    </div>

    <div class="testimonial-card">
        <img src="images/hems.png" alt="Righteous Smith">
        <h3>Righteous Smith</h3>
        <span>Client</span>
        <p>
            “Working with Momoh was a pleasure. He turned our ideas into a functional app
            that exceeded expectations. Highly recommended!”
        </p>
    </div>

    <div class="testimonial-card">
        <img src="images/user3.jpg" alt="Ahmed Kamara">
        <h3>Ahmed Kamara</h3>
        <span>Team Lead</span>
        <p>
            “Professional, creative, and reliable. His code is clean and his UI skills are excellent.”
        </p>
    </div>

</section>

</body>
</html>
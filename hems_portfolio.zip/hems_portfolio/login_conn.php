<?php
session_start();

// 🔌 DATABASE CONNECTION
$host = "localhost";
$user = "root";
$dbname = "limbaman";

$conn = new mysqli($host, $user, '', $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 🔐 LOGIN LOGIC
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query using email
    $sql = "SELECT * FROM visitors WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        $row = $result->fetch_assoc();

        // Check password
        if ($row['user_pass'] == $password) {
            $_SESSION['email'] = $email; // login success
            
            header("Location: home.php");
            exit();

        } else {
            header("Location: index.php?error=1");
            exit();
        }

    } else {
        header("Location: index.php?error=1");
        exit();
    }
}
?>

<?php
    
    $conn = new mysqli('localhost', 'root', '','limbaman');

    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (!$full_name || !$email || !$password || !$confirm_password) {
        header("Location: signup.php?status=missing");
        exit();
    }

    if ($password !== $confirm_password) {
        header("Location: signup.php?status=mismatch");
        exit();
    }

$check = $conn->prepare("SELECT id FROM visitors WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    $check->close();
    $conn->close();
    header("Location: signup.php?status=exists");
    exit();
}

$check->close();

    $hashed = password_hash($password, PASSWORD_BCRYPT);

    if($conn->connect_error){
        die('connection failed : '.$conn->connect_error);
    }
    
    $stmt = $conn->prepare("insert into visitors(full_name, email, password) values(?,?,?)");
    $stmt->bind_param("sss",$full_name, $email, $hashed);

    if ($stmt->execute()){
        $stmt->close();
        $conn->close();
        header("location: signup.php?status=success");
        exit();
    }
    else{
        $stmt->close();
        $conn->close();
        header("location: signup.php?status=error");
        exit();
    }
    
?>
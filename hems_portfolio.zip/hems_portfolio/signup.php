<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign Up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/register.css">
  </head>
  <body>
    <div class="container">
        <div class="card">

            <div class="logo">
                <img src="images/rmb.png" alt="logo">
            </div>
            
            <div class="sign">
                <h1 class="sign_up">Sign Up</h1>
            </div>

            <div id="status-message"></div>
        
            <div class="register">
                <form action="users_conn.php" method="post">

                    <input type="text" name="full_name" id="full_name" class="form-control" required autofocus placeholder="Full Name"> <br>

                    <input type="email" name="email" id="emailAddress" class="form-control" required autofocus placeholder="Email Address"> <br>

                    <div class="password_wrapper">
                        <input type="password" name="password" id="password" class="form-control" required autofocus autocomplete="new-password" placeholder="Password">
                        <i class="fa-solid fa-eye toggle" onclick="togglePassword('password', this)"></i>
                    </div>

                    <div class="password_wrapper">
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" required autofocus autocomplete="new-password" placeholder="Confirm Password">
                        <i class="fa-solid fa-eye toggle" onclick="togglePassword('confirm_password', this)"></i>
                    </div>

                    <div class="regBtn">
                        <button class="btn btn-lg btn-primary ">Sign Up</button>
                    </div><br>

                    <div class="login">
                        <p>You already have an account? <a href="index.php">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    
        function togglePassword(id, icon) {
        const field = document.getElementById(id);

            if (field.type === "password") {
                field.type = "text";
                icSon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            } else {
                field.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            }
        }
        const params = new URLSearchParams(window.location.search);
        const status = params.get('status');
        const statusMessage = document.getElementById('status-message');

        if (status === "success") statusMessage.innerHTML = '<div class="status success">Registration Successful!</div>';
        else if (status === "error") statusMessage.innerHTML = '<div class="status error">Registration Failed!</div>';
        else if (status === "mismatch") statusMessage.innerHTML = '<div class="status error">Passwords do not match!</div>';
        else if (status === "missing") statusMessage.innerHTML = '<div class="status error">All fields are required!</div>';
        else if (status === "exists") statusMessage.innerHTML = '<div class="status error">Email already registered!</div>';
    </script>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>
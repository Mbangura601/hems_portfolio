<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Info</title>
    <link rel="stylesheet" href="css/contact.css">
</head>

<body>

    <!-- ================= NAVBAR ================= -->
    <nav class="navbar">
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="About_me.php">About</a></li>
            <li><a href="Skills.php">Skills</a></li>
            <li><a href="Project.php">Project</a></li>
            <li><a href="testimonial.php">Testimonials</a></li>
            <li><a href="logout.php" class="logout-btn">Log Out</a></li>
        </ul>
    </nav>

    <!-- ================= CONTACT WRAPPER ================= -->
    <div class="contact_wrapper fade-in">

        <!-- LEFT SIDE -->
        <div class="info_section">

            <h2>Get in Touch</h2>

            <p class="subtitle">
                Let’s build something amazing together.
            </p>

            <p>
                I’m available for freelance work, collaborations,
                and full-time opportunities in Front-End and Mobile App Development.
            </p>

            <!-- CONTACT INFO BOX -->
            <div class="contact_box">
                <p><strong>Email:</strong> mbangura601@gmail.com</p>
                <p><strong>Phone:</strong> +232 88 392 627</p>
                <p><strong>Location:</strong> Freetown, Sierra Leone</p>
            </div>

            <!-- AVAILABILITY -->
            <div class="availability">
                <span class="dot"></span>
                Available for work
            </div>

            <!-- SOCIAL LINKS -->
            <div class="socials">
                <p>Follow me:</p>
                <a href="https://www.facebook.com/share/1DbsV5ZSDf/">Facebook</a>
                <a href="https://github.com/Mbangura601">GitHub</a>
                <a href="https://www.instagram.com/limba_man1?igsh=Z21ncGVmaTUxNGR1">Instagram</a>
            </div>

            <!-- QUICK CONTACT BUTTONS -->
            <div class="quick_contact">

                <a href="https://wa.me/23288392726?text=Hello%20I%20am%20interested%20in%20your%20services"
                   target="_blank"
                   class="whatsapp_btn">
                    📱 Chat on WhatsApp
                </a>

                <a href="mailto:mbangura601@gmail.com?subject=Project%20Inquiry&body=Hello%20I%20would%20like%20to%20discuss%20a%20project"
                   class="email_btn">
                    📧 Send Email
                </a>

            </div>

        </div>

        <!-- RIGHT SIDE FORM -->
        <div class="form_box">

            <form id="contactForm" action="connect.php" method="post">

                <label>Full Name</label>
                <input type="text" name="full_name" required>

                <label>Email</label>
                <input type="email" name="email" required>

                <label>Message</label>
                <textarea name="message" required></textarea>

                <button type="submit">Send Message</button>

            </form>

        </div>

    </div>

    <!-- ================= JS ================= -->
    <script src="js/contact.js"></script>

</body>
</html>
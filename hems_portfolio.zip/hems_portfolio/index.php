<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/login.css">
</head>

<body>
    <div class="container">
        <div class="card">

            <div class="logo">
                <img src="images/rmb.png" alt="logo">
            </div>

            <div class="login">
                <h1>Login</h1>
            </div>

            <!-- ❗ Error box must be ABOVE form -->
            <div id="errorBox"></div>

            <div class="form">
                <form id="loginForm" action="login_conn.php" method="post" autocomplete="off">

                    <input type="email" name="email" id="email"
                        class="form-control" required placeholder="Email Address"><br>

                    <div class="password_wrapper">
                        <input type="password" name="user_pass" id="password"
                            class="form-control" required placeholder="Password"
                            autocorrect="off" autocapitalize="off"
                            >

                        <i class="fa-solid fa-eye toggle" onclick="togglePassword('password', this)"></i>
                    </div>

                    <div class="rememberMe">
                        <label>
                            <input type="checkbox"> Remember me
                        </label>
                    </div>

                    <div class="loginBtn">
                        <button name="login" class="btn btn-lg btn-primary">Login</button>
                    </div>
                </form>
            </div>

            <div class="reg">
                <p>Don't have an account? <a href="signup.php">Register</a></p>
            </div>

        </div>
    </div>

    <script>
        // Toggle password field
        function togglePassword(id, icon) {
            const field = document.getElementById(id);

            if (field.type === "password") {
                field.type = "text";
                icon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                field.type = "password";
                icon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }

        // Form validation
        document.getElementById("loginForm").addEventListener("submit", function(e) {

            const email = document.getElementById("emailAddress").value.trim();
            const password = document.getElementById("password").value.trim();
            const alertBox = document.getElementById("errorBox");

            alertBox.innerHTML = "";

            // Email required
            if (email === "") {
                e.preventDefault();
                alertBox.innerHTML =
                    '<div class="alert alert-danger text-center">Email is required.</div>';
                return;
            }

            // Email pattern
            const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,}$/i;
            if (!emailPattern.test(email)) {
                e.preventDefault();
                alertBox.innerHTML =
                    '<div class="alert alert-danger text-center">Enter a valid email address.</div>';
                return;
            }

            // Password required
            if (password === "") {
                e.preventDefault();
                alertBox.innerHTML =
                    '<div class="alert alert-danger text-center">Password is required.</div>';
                return;
            }

            // Password length
            if (password.length < 6) {
                e.preventDefault();
                alertBox.innerHTML =
                    '<div class="alert alert-danger text-center">Password must be 6+ characters.</div>';
                return;
            }

            // All good → normal submit
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="css/about.css">
</head>

<body>

    <!-- Sticky Navbar -->
    <nav class="navbar">
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="Skills.php">Skills</a></li>
            <li><a href="Project.php">Project</a></li>
            <li><a href="testimonial.php">Testimonials</a></li>
            <li><a href="Contact_info.php">Contact</a></li>
            <li><a href="logout.php" class="logout-btn">Log Out</a></li>
        </ul>
    </nav>

    <section class="about_section fade-in">
        <div class="profile_box">
            <img src="images/hems.png" alt="Profile Image">
            <h2>Momoh Hemon-Bangura</h2>
            <p>Front-End | Mobile App Developer</p>
        </div>

        <div class="about_content">
            <h3>About Me</h3>

            <p id="aboutText">
                I am Momoh Hemon-Bangura, a passionate Front-End and Mobile App Developer dedicated 
                to creating clean, responsive, and user-focused digital experiences. With a strong 
                foundation in HTML, CSS, JavaScript, React, and Flutter, I build applications that 
                are visually appealing, highly functional, and intuitive. <span id="moreText" style="display:none;">
                
                My goal is to transform ideas into functional interfaces and mobile applications that 
                solve real problems, engage users, and deliver value. I thrive in both collaborative 
                and independent environments and continuously explore the latest technologies to 
                enhance the quality of my work.
                </span>
            </p>

            <button id="readMoreBtn">Read More</button>
        </div>
    </section>

    <!-- Skills Bar Section -->
    <section class="skills_section fade-in" id="skills">
        <h3>My Skills</h3>

        <div class="skill">
            <p>HTML</p>
            <div class="skill_bar"><span data-percent="95%"></span></div>
        </div>

        <div class="skill">
            <p>CSS</p>
            <div class="skill_bar"><span data-percent="90%"></span></div>
        </div>

        <div class="skill">
            <p>JavaScript</p>
            <div class="skill_bar"><span data-percent="85%"></span></div>
        </div>

        <div class="skill">
            <p>React</p>
            <div class="skill_bar"><span data-percent="80%"></span></div>
        </div>

        <div class="skill">
            <p>Flutter</p>
            <div class="skill_bar"><span data-percent="75%"></span></div>
        </div>
    </section>

    <script src="js/about.js"></script>
</body>
</html>
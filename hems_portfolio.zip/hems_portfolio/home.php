<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hemon Bangura | Portfolio</title>
    <link rel="stylesheet" href="css/home.css">
</head>

<body>

<!-- ================= NAVBAR ================= -->
<nav class="navbar">
    <ul>
        <li><a href="About_me.php">About</a></li>
        <li><a href="Skills.php">Skills</a></li>
        <li><a href="Project.php">Project</a></li>
        <li><a href="testimonial.php">Testimonials</a></li>
        <li><a href="Contact_info.php">Contact</a></li>
        <li><a href="logout.php" class="logout-btn">Log Out</a></li>
    </ul>
</nav>

<!-- ================= HERO SECTION ================= -->
<header class="hero container">

    <div class="hems">

        <h3>Hello, I'm</h3>

        <h1>Momoh Hemon-Bangura</h1>

        <!-- typing effect target -->
        <h2 class="typing">Front-End & Mobile App Developer</h2>

        <p>
            I build modern, responsive, and user-focused websites and mobile applications
            that solve real problems and deliver great user experiences.
        </p>

        <div class="cta">
            <a href="Contact_info.php" class="btn primary">Hire Me</a>
            <a href="Project.php" class="btn secondary">View Work</a>
        </div>

    </div>
</header>

<!-- ================= ABOUT ================= -->
<section class="section">
    <h2>About Me</h2>
    <p>
        I am a passionate Front-End and Mobile App Developer focused on creating
        clean UI, smooth user experiences, and scalable digital solutions.
    </p>
</section>

<!-- ================= SKILLS ================= -->
<section class="section">
    <h2>Skills</h2>

    <div class="skills">

        <div class="skill">
            <p>HTML</p>
            <div class="bar"><div class="fill" style="width: 95%"></div></div>
        </div>

        <div class="skill">
            <p>CSS</p>
            <div class="bar"><div class="fill" style="width: 90%"></div></div>
        </div>

        <div class="skill">
            <p>JavaScript</p>
            <div class="bar"><div class="fill" style="width: 50%"></div></div>
        </div>
        
        <div class="skill">
            <p>Database</p>
            <div class="bar"><div class="fill" style="width: 85%"></div></div>
        </div>

        <div class="skill">
            <p>Back-End</p>
            <div class="bar"><div class="fill" style="width: 50%"></div></div>
        </div>
    </div>
</section>

<!-- ================= PROJECTS ================= -->
<section class="section">
    <h2>Projects</h2>
    <p>Explore some of my recent work and development projects.</p>

    <div class="cards">
        <div class="card">Portfolio Website</div>
        <div class="card">Mobile App UI</div>
        <div class="card">Business Landing Page</div>
    </div>

    <div class="cta">
        <a href="Project.php" class="btn primary">View Projects</a>
    </div>
</section>

<script src="js/script.js"></script>
</body>
</html>

/* ================= FILTER SYSTEM ================= */
const filters = document.querySelectorAll(".filter");
const cards = document.querySelectorAll(".skill-card");

filters.forEach(btn => {
    btn.addEventListener("click", () => {

        // active state
        filters.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const type = btn.dataset.filter;

        cards.forEach(card => {

            if (type === "all") {
                card.style.display = "block";
            } else {
                card.style.display = card.classList.contains(type)
                    ? "block"
                    : "none";
            }
        });
    });
});


/* ================= ANIMATE SKILLS ON SCROLL ================= */
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {

        if (entry.isIntersecting) {

            const card = entry.target;
            const fill = card.querySelector(".fill");
            const count = card.querySelector(".count");

            const target = parseInt(fill.dataset.percent);
            let current = 0;

            // Prevent re-animation
            if (fill.classList.contains("animated")) return;
            fill.classList.add("animated");

            // Animate bar
            fill.style.width = target + "%";

            // Animate counter
            const interval = setInterval(() => {
                if (current >= target) {
                    clearInterval(interval);
                } else {
                    current++;
                    count.textContent = current + "%";
                }
            }, 15);
        }
    });
}, {
    threshold: 0.4
});


cards.forEach(card => {
    observer.observe(card);
});


/* ================= OPTIONAL: SMOOTH NAV ACTIVE ================= */
const navLinks = document.querySelectorAll("nav ul li a");

navLinks.forEach(link => {
    link.addEventListener("click", () => {
        navLinks.forEach(l => l.classList.remove("active"));
        link.classList.add("active");
    });
});
// Read More Toggle
const readMoreBtn = document.getElementById("readMoreBtn");
const moreText = document.getElementById("moreText");

readMoreBtn.addEventListener("click", () => {
    if (moreText.style.display === "none") {
        moreText.style.display = "inline";
        readMoreBtn.textContent = "Read Less";
    } else {
        moreText.style.display = "none";
        readMoreBtn.textContent = "Read More";
    }
});

// Skills Bar Animation on Scroll
const skillBars = document.querySelectorAll(".skill_bar span");

function animateSkills() {
    skillBars.forEach(bar => {
        const percent = bar.getAttribute("data-percent");
        bar.style.width = percent;
    });
}

window.addEventListener("scroll", () => {
    const skillsSection = document.querySelector(".skills_section");
    const sectionPos = skillsSection.getBoundingClientRect().top;

    if (sectionPos < window.innerHeight - 100) {
        animateSkills();
    }
});
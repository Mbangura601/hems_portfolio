const text = "Front-End & Mobile App Developer";
let index = 0;

function typeEffect() {
    const target = document.querySelector(".typing");

    if (!target) return;

    target.textContent = text.slice(0, index);

    index++;

    if (index > text.length) {
        index = 0; // restart loop
        setTimeout(typeEffect, 1000);
        return;
    }

    setTimeout(typeEffect, 100);
}

typeEffect();
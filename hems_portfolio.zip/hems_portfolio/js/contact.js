document.addEventListener("DOMContentLoaded", () => {

    // =========================
    // CONTACT FORM VALIDATION
    // =========================
    const form = document.getElementById("contactForm");

    if (form) {
        form.addEventListener("submit", function (e) {

            const name = form.full_name.value.trim();
            const email = form.email.value.trim();
            const message = form.message.value.trim();

            // Check empty fields
            if (!name || !email || !message) {
                e.preventDefault();
                alert("⚠ Please fill in all fields before submitting.");
                return;
            }

            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailPattern.test(email)) {
                e.preventDefault();
                alert("⚠ Please enter a valid email address.");
                return;
            }

            alert("✅ Message sent successfully!");

            // reset form after slight delay
            setTimeout(() => {
                form.reset();
            }, 400);
        });
    }


    // =========================
    // BUTTON PRESS EFFECTS
    // =========================
    const buttons = document.querySelectorAll("button, .whatsapp_btn, .email_btn");

    buttons.forEach(btn => {

        btn.addEventListener("mousedown", () => {
            btn.style.transform = "scale(0.96)";
        });

        btn.addEventListener("mouseup", () => {
            btn.style.transform = "scale(1)";
        });

        btn.addEventListener("mouseleave", () => {
            btn.style.transform = "scale(1)";
        });
    });


    // =========================
    // SMOOTH SCROLL (for # links only)
    // =========================
    document.querySelectorAll('a[href^="#"]').forEach(link => {

        link.addEventListener("click", function (e) {
            e.preventDefault();

            const target = document.querySelector(this.getAttribute("href"));

            if (target) {
                target.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }
        });
    });


    // =========================
    // WHATSAPP CLICK LOG (DEBUG / OPTIONAL)
    // =========================
    const whatsappBtn = document.querySelector(".whatsapp_btn");

    if (whatsappBtn) {
        whatsappBtn.addEventListener("click", () => {
            console.log("WhatsApp clicked");
        });
    }


    // =========================
    // EMAIL CLICK LOG (DEBUG / OPTIONAL)
    // =========================
    const emailBtn = document.querySelector(".email_btn");

    if (emailBtn) {
        emailBtn.addEventListener("click", () => {
            console.log("Email clicked");
        });
    }

});
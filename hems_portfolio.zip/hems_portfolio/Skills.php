<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/skills.css">
    <title>Skills</title>
</head>

<body>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="About_me.php">About</a></li>
            <li><a href="Project.php">Project</a></li>
            <li><a href="testimonial.php">Testimonials</a></li>
            <li><a href="Contact_info.php">Contact</a></li>
            <li><a href="logout.php" class="logout-btn">Log Out</a></li>
        </ul>
    </nav>
    
    <!-- ================= HEADER ================= -->
<header class="skills-header">
    <h1>My Skills</h1>
    <p>Technologies I use to build scalable, modern applications.</p>
</header>

<!-- ================= FILTER BUTTONS ================= -->
<div class="filter-container">
    <button class="filter active" data-filter="all">All</button>
    <button class="filter" data-filter="frontend">Frontend</button>
    <button class="filter" data-filter="backend">Backend</button>
    <button class="filter" data-filter="mobile">Mobile</button>
    <button class="filter" data-filter="tools">Tools</button>
</div>

<!-- ================= SKILLS GRID ================= -->
<section class="skills-grid">

    <!-- Frontend -->
    <div class="skill-card frontend">
        <h3>HTML</h3>
        <div class="bar"><div class="fill" data-percent="95"></div></div>
        <span class="count">0%</span>
    </div>

    <div class="skill-card frontend">
        <h3>CSS</h3>
        <div class="bar"><div class="fill" data-percent="90"></div></div>
        <span class="count">0%</span>
    </div>

    <div class="skill-card frontend">
        <h3>JavaScript</h3>
        <div class="bar"><div class="fill" data-percent="85"></div></div>
        <span class="count">0%</span>
    </div>

    <!-- Backend -->
    <div class="skill-card backend">
        <h3>PHP</h3>
        <div class="bar"><div class="fill" data-percent="80"></div></div>
        <span class="count">0%</span>
    </div>

    <div class="skill-card backend">
        <h3>MySQL</h3>
        <div class="bar"><div class="fill" data-percent="75"></div></div>
        <span class="count">0%</span>
    </div>

    <!-- Mobile -->
    <div class="skill-card mobile">
        <h3>Flutter</h3>
        <div class="bar"><div class="fill" data-percent="70"></div></div>
        <span class="count">0%</span>
    </div>

    <!-- Tools -->
    <div class="skill-card tools">
        <h3>Git / GitHub</h3>
        <div class="bar"><div class="fill" data-percent="85"></div></div>
        <span class="count">0%</span>
    </div>

</section>

<script src="js/skills.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/project.css">
    <title>Document</title>
</head>

<body>

    <nav class="navbar">
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="About_me.php">About</a></li>
            <li><a href="Skills.php">Skills</a></li>
            <li><a href="testimonial.php">Testimonials</a></li>
            <li><a href="Contact_info.php">Contact</a></li>
            <li><a href="logout.php" class="logout-btn">Log Out</a></li>
        </ul>
    </nav>

    <!-- ================= PROJECT HEADER ================= -->
    <section class="project-header">
        <h1>My Projects</h1>
        <p>Explore my work in web development, mobile apps, and UI design.</p>

        <input type="text" id="searchInput" placeholder="Search projects...">
    </section>

    <!-- ================= FILTER BUTTONS ================= -->
    <div class="filters">
        <button class="filter-btn active" data-filter="all">All</button>
        <button class="filter-btn" data-filter="web">Web</button>
        <button class="filter-btn" data-filter="mobile">Mobile</button>
        <button class="filter-btn" data-filter="ui">UI Design</button>
    </div>

    <!-- ================= PROJECT GRID ================= -->
    <section class="project-grid">

        <div class="project-card web">
            <h3>Portfolio Website</h3>
            <p>Responsive personal portfolio built with HTML, CSS, JS.</p>
        </div>

        <div class="project-card mobile">
            <h3>Food Delivery App</h3>
            <p>Mobile UI concept for food ordering system.</p>
        </div>

        <div class="project-card ui">
            <h3>Dashboard UI</h3>
            <p>Modern admin dashboard interface design.</p>
        </div>

        <div class="project-card web">
            <h3>E-commerce Website</h3>
            <p>Online shop with product listing and cart system.</p>
        </div>

    </section>

<script src="js/project.js"></script>
    
</body>
</html>
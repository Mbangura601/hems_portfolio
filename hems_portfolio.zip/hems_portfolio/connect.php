<?php
    
    $conn = new mysqli('localhost', 'root', '','limbaman');

    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    if($conn->connect_error){
        die('connection failed : '.$conn->connect_error);
    }
    else{
        $stmt = $conn->prepare("insert into contact(full_name, email, message) values(?,?,?)");
        $stmt->bind_param("sss",$full_name, $email, $message);

        if ($stmt->execute()){
            header("location: Contact_info.php?status=success");
            exit();
        }
        else{
            header("location: Contact_info.php?status=error");
            $stmt->close();
            exit();
        }
    }
    $conn->close();
?>